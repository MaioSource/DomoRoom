package com.domohouse.amaio.domoroom;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;

public class MainControl extends AppCompatActivity {

    WebView webview2;
    Switch swLuzPrincipal;
    Switch swLuzSecundaria;
    Switch swCortina;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_control);
        webview2 = (WebView) findViewById(R.id.webView2);
        webview2.loadUrl("http://192.168.0.50");

        //Luz principal
        swLuzPrincipal = (Switch) findViewById(R.id.swLuzPrincipal);
        swLuzPrincipal.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b)
                    webview2.loadUrl("http://192.168.0.50/?luzON");

                else
                    webview2.loadUrl("http://192.168.0.50/?luzOFF");
            }
        });

        //Luz secundaria
        swLuzSecundaria = (Switch) findViewById(R.id.swLuzSecundaria);
        swLuzSecundaria.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b)
                    webview2.loadUrl("http://192.168.0.50/?luzSecON");
                else
                    webview2.loadUrl("http://192.168.0.50/?luzSecOFF");
            }
        });

        //Cortina
        swCortina = (Switch) findViewById(R.id.swCortina);
        swLuzSecundaria.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b)
                    webview2.loadUrl("http://192.168.0.50/?cortinaUP");
                else
                    webview2.loadUrl("http://192.168.0.50/?cortinaDOWN");
            }
        });



    }
}
